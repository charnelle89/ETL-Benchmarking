import argparse, json, os, glob
import pandas as pd
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    rows = []
    for fp in glob.glob("results/raw_runs/*/metrics.json"):
        with open(fp, "r", encoding="utf-8") as f:
            rows.append(json.load(f))
    if not rows:
        print("no metrics found.")
        return
    df = pd.DataFrame(rows)
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    df.to_parquet(args.out, index=False)
    print(f"[ok] wrote {args.out} with {len(df)} rows.")
if __name__ == "__main__":
    main()
