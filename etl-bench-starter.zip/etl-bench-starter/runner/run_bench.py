import argparse, json, os, time, uuid, random
from datetime import datetime
def fake_run(stack:str, volume:str):
    t0 = time.time()
    time.sleep(0.5 + random.random())
    metrics = {
        "run_id": str(uuid.uuid4()),
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "stack": stack,
        "volume": volume,
        "latency_sec": round(time.time() - t0, 3),
        "throughput_gb_per_min": None,
        "p95_ms": None,
        "p99_ms": None,
        "success": True
    }
    return metrics
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stack", required=True, choices=["spark","duckdb"])
    ap.add_argument("--volume", required=True, choices=["1gb","10gb","100gb"])
    args = ap.parse_args()
    metrics = fake_run(args.stack, args.volume)
    run_id = metrics["run_id"]
    out_dir = f"results/raw_runs/{run_id}"
    os.makedirs(out_dir, exist_ok=True)
    out_fp = os.path.join(out_dir, "metrics.json")
    with open(out_fp, "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2, ensure_ascii=False)
    print(f"[ok] wrote {out_fp}")
if __name__ == "__main__":
    main()
