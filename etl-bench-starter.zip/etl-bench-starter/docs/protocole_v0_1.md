# Protocole expérimental v0.1 — ETL Benchmark
**Date**: 2025-11-10 | **Version**: 0.1 | **Auteur**: Charnelle
