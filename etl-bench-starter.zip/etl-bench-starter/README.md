# ETL Benchmark – Starter (Step 1)

Ce dépôt sert de **point de départ** pour ton Forschungsprojekt (12 ECTS).
**Étape 1** = cadrer *protocole v0.1* + figer les paramètres initiaux.
